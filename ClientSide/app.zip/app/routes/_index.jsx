
export default function Index() {
  return (
   <>
   <h1>index page</h1>
   </>
  );
}

